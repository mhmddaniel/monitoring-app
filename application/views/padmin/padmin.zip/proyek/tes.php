	
<form name='autoSumForm'  action="<?php echo base_url()?>padmin/upfile" method="POST" enctype="multipart/form-data" >
	<div class="form-group col-md-6">
		<label>LAMPIRAN</label>
		<input type="file"  name="fileat" class="form-control btn-success">
	</div>


	<div class="form-group pull-right">
		<button type="submit" class="btn btn-primary btn-flat pull-right"><span class="fa fa-pencil"></span> Publish</button>
	</div>
</form>